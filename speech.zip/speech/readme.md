javah -d "生成头文件的位置" "类全限定名称"

javap -s 查看签名信息