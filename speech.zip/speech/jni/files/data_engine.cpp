#include <jni.h>
#include <string>


#include "log.h"

#include "com_sogou_speech_utils_DataEngine.h"

using namespace std;


JNIEXPORT jint JNICALL Java_com_sogou_speech_utils_DataEngine_add__IF(JNIEnv *env, jclass jclazz, jint a, jfloat b){
    return (int)(a+b);
}


JNIEXPORT jint JNICALL Java_com_sogou_speech_utils_DataEngine_add___3I(JNIEnv * env, jclass jclazz, jintArray arr){
    int total = 0;
    jint* int_arr = env->GetIntArrayElements(arr,NULL);
    jsize len = env->GetArrayLength(arr);
    for(int i = 0;i<len;i++){
        total+=int_arr[i];
    }

    // env->ReleaseIntArrayElements(arr,int_arr,JNI_ABORT);

    return total;
}


JNIEXPORT jstring JNICALL Java_com_sogou_speech_utils_DataEngine_getToken(JNIEnv *env, jclass jclazz){
   char res[] = "hello world";
   return env->NewStringUTF(res);
}


JNIEXPORT jstring JNICALL Java_com_sogou_speech_utils_DataEngine_getPwd(JNIEnv * env, jclass jclazz, jstring jstr){
    const char* inputStr = env->GetStringUTFChars(jstr,NULL);
    char defaultName[] = "Tom";

    int res = strcasecmp(inputStr,defaultName);
    char *ret = NULL;
    if(res == 0){
        ret = "success";
    }else{
        ret = "fail";
    }

    return env->NewStringUTF(ret);
}


JNIEXPORT jint JNICALL Java_com_sogou_speech_utils_DataEngine_checkout(JNIEnv *env, jclass jclazz, jobject jobj){
    //获得jfieldID 以及 该字段的初始值
    jfieldID  nameFieldId ;

    jclass cls = env->GetObjectClass(jobj);  //获得Java层该对象实例的类引用，即HelloJNI类引用

    nameFieldId = env->GetFieldID(cls , "name" , "Ljava/lang/String;"); //获得属性句柄
    jstring javaNameStr = (jstring)env->GetObjectField(jobj ,nameFieldId);  // 获得该属性的值
    const char * c_javaName = env->GetStringUTFChars(javaNameStr , NULL);  //转换为 char *类型
    std::string str_name = c_javaName ;
    env->ReleaseStringUTFChars(javaNameStr , c_javaName);  //释放局部引用

    nameFieldId = env->GetFieldID(cls , "pwd" , "Ljava/lang/String;"); //获得属性句柄
    jstring javaPwdStr = (jstring)env->GetObjectField(jobj ,nameFieldId);  // 获得该属性的值
    const char * c_javaPwd = env->GetStringUTFChars(javaPwdStr , NULL);  //转换为 char *类型
    std::string str_pwd = c_javaPwd ;
    env->ReleaseStringUTFChars(javaPwdStr , c_javaPwd);  //释放局部引用

    int ret  = 0;
    if(str_name.compare("123") == 0 && str_pwd.compare("456") == 0){
        ret = 0;
    }else{
        ret = -1;
    }

    LOGI("%s",c_javaPwd);

    return ret;
}

JNIEXPORT void JNICALL Java_com_sogou_speech_utils_DataEngine_init(JNIEnv *env, jobject jobj, jintArray jarr){

     //方法一
     /*
       jint temp1 = 45,temp2 = 20;
       (*env)->SetIntArrayRegion(env,javaArray,1,1,&temp1);
       (*env)->SetIntArrayRegion(env,javaArray,2,1,&temp2);
              */

      //方法二：
      jint * temp = (jint*) env->GetIntArrayElements(jarr, 0);
      jsize len = env->GetArrayLength(jarr);
      for(int i = 0;i<len;i++){
          temp[i] = i;
      }
      env->SetIntArrayRegion(jarr, 0,len,temp);
}

JNIEXPORT jboolean JNICALL Java_com_sogou_speech_utils_DataEngine_verify
  (JNIEnv *env, jobject jobj, jshortArray jarr){
    jshort* short_arr = env->GetShortArrayElements(jarr,NULL);
    jsize len = env->GetArrayLength(jarr);
    int total = 0;
    for(int i = 0;i<len;i++){
        total+=short_arr[i];
    }

    jboolean ret = false;
    if(total == 100){
        ret = true;
    }

    return ret;

}

JNIEXPORT jshortArray JNICALL Java_com_sogou_speech_utils_DataEngine_vad(JNIEnv *env, jobject jobj, jshortArray jarr){
    jshort* short_arr = env->GetShortArrayElements(jarr,NULL);
    jsize len = env->GetArrayLength(jarr);

    jshortArray ret = env->NewShortArray(len);
    jshort buf[1] = {0};

    for(int i = 0;i<len;i++){
        buf[0] = short_arr[i]+100;
        env->SetShortArrayRegion(ret,i,1,buf);
    }

    return ret;
}

JNIEXPORT jobject JNICALL Java_com_sogou_speech_utils_DataEngine_getAccount(JNIEnv *env, jobject jobj){
    jclass clazz = env->FindClass("com/sogou/speech/domain/Account");
    jmethodID account_init = env->GetMethodID(clazz,"<init>","()V");
    jobject account = env->NewObject(clazz, account_init);


    jfieldID  m_fid_time = env->GetFieldID(clazz,"time","J");
    env->SetLongField(account,m_fid_time,110L);

    jfieldID  m_fid_name = env->GetFieldID(clazz,"name","Ljava/lang/String;");
    jstring cName = env->NewStringUTF("jni name"); //构造一个jstring对象
    env->SetObjectField(account,m_fid_name,cName);

    jfieldID  m_fid_pwd = env->GetFieldID(clazz,"pwd","Ljava/lang/String;");
    jstring cPwd = env->NewStringUTF("jni name"); //构造一个jstring对象
    env->SetObjectField(account,m_fid_pwd,cPwd);

    return account;
}


JNIEXPORT jint JNICALL Java_com_sogou_speech_utils_DataEngine_checkout(JNIEnv * env, jclass jclazz, jobject account, jobject callback){

    jclass clazz  = env->GetObjectClass(account); //获得account类引用

    jfieldID timeFieldID = env->GetFieldID(clazz,"time","J"); //获得得Student类的属性id
    jfieldID nameFieldID = env->GetFieldID(clazz,"name","Ljava/lang/String;"); // 获得属性ID
    jfieldID pwdFieldID = env->GetFieldID(clazz,"pwd","Ljava/lang/String;"); // 获得属性ID

    jlong time = env->GetLongField(account , timeFieldID);  //获得属性值
    LOGI("time: %d",time);

    jstring name = (jstring)env->GetObjectField(account , nameFieldID);//获得属性值
    const char * c_name = env->GetStringUTFChars(name ,NULL);//转换成 char *
    LOGI("name: %s",c_name);
    string str_name = c_name ;
    env->ReleaseStringUTFChars(name,c_name); //释放引用

    jstring pwd = (jstring)env->GetObjectField(account , pwdFieldID);//获得属性值
    const char * c_pwd = env->GetStringUTFChars(pwd ,NULL);//转换成 char *
    LOGI("pwd: %s",c_pwd);
    string str_pwd = c_pwd;
    env->ReleaseStringUTFChars(pwd,c_pwd); //释放引用

    jclass cls = env->GetObjectClass(callback);
    jmethodID callbackId = env->GetMethodID(cls,"callback","(ILjava/lang/String;)V");
    jstring msg = env->NewStringUTF("I am a Callback!");
    env->CallVoidMethod(callback,callbackId,-1,msg);

    return 0;
}

